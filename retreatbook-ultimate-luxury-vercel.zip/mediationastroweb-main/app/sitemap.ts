import { MetadataRoute } from "next"

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = "https://answerforself.com"

  const routes = [
    "",
    "/h",
    "/h/about",
    "/h/about/philosophy",
    "/h/about/why-answerforself",

    "/h/answers",
    "/h/answers/life-questions",
    "/h/answers/mental-health",
    "/h/answers/relationships",
    "/h/answers/career-purpose",
    "/h/answers/spiritual-growth",

    "/h/guides-tools",
    "/h/guides-tools/self-reflection-guides",
    "/h/guides-tools/journaling-prompts",
    "/h/guides-tools/decision-making-tools",

    "/h/blogs",
    "/h/resources",
    "/h/resources/free-downloads",
    "/h/resources/recommended-books",
    "/h/resources/external-help-links",

    "/h/community",
    "/h/community/ask-a-question",
    "/h/community/stories",

    "/h/retreats",
    "/h/contact",
    "/h/legal",
    "/h/privacy",
    "/h/terms-and-conditions",
    "/h/faq",

    // Existing service pages
    "/h/services",
    "/h/appointment",
    "/h/astrological-chart-reading",
    "/h/meditation-and-yoga",
    "/h/spiritual-guidance",
    "/h/jyotish-consultancy",
    "/h/gallery",
    "/h/shop",
  ].map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: "weekly" as const,
    priority: route === "" || route === "/h" ? 1 : 0.7,
  }))

  return routes
}
