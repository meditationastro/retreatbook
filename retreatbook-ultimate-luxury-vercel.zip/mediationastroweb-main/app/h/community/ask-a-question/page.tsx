"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"

export default function Page() {
  const { toast } = useToast()
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [question, setQuestion] = useState("")

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    toast({
      title: "Question saved (demo)",
      description: "Hook this form to your API/email when you're ready.",
    })
    setName("")
    setEmail("")
    setQuestion("")
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white">
      <section className="container mx-auto px-4 py-14">
        <p className="text-sm text-primary-700">
          <Link href="/h/community">← Back to Community</Link>
        </p>
        <h1 className="mt-3 text-4xl font-bold text-primary-900">Ask a Question</h1>
        <p className="mt-4 text-lg text-primary-800/80 max-w-2xl">
          Submit a question you’d like AnswerForSelf to cover. This form is set up as a static placeholder,
          ready to connect to an API, email workflow, or CMS later.
        </p>

        <Card className="mt-10 max-w-2xl border-primary-200 bg-white/80">
          <CardHeader>
            <CardTitle className="text-primary-900">Your Question</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={onSubmit} className="space-y-4">
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Name (optional)" />
              <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email (optional)" type="email" />
              <Textarea value={question} onChange={(e) => setQuestion(e.target.value)} placeholder="Write your question..." rows={6} />
              <Button className="bg-gradient-to-r from-blue-800 to-amber-600 text-white" type="submit">
                Submit
              </Button>
            </form>
          </CardContent>
        </Card>
      </section>
    </div>
  )
}
