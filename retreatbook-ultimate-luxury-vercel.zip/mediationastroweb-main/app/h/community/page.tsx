  import Link from "next/link"
  import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
  import { Button } from "@/components/ui/button"

  const items = [
    { title: "Ask a Question", href: "/h/community/ask-a-question", description: "Submit a question for future answers and articles." },
{ title: "Stories from Readers", href: "/h/community/stories", description: "Share what helped you—your story might guide someone else." }
  ]

  export default function Page() {
    return (
      <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white">
        <section className="container mx-auto px-4 py-14">
          <div className="max-w-3xl">

            <h1 className="text-4xl font-bold text-primary-900">Community</h1>
            <p className="mt-4 text-lg text-primary-800/80">A place for readers to ask questions and share growth stories (built to expand later).</p>
          </div>

          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {items.map((it) => (
              <Card key={it.href} className="border-primary-200 shadow-sm hover:shadow-md transition-shadow bg-white/80">
                <CardHeader>
                  <CardTitle className="text-primary-900">{it.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-primary-800/80 mb-4">{it.description}</p>
                  <Link href={it.href}>
                    <Button className="bg-gradient-to-r from-blue-800 to-amber-600 text-white">Explore</Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </div>
    )
  }
