import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Page() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white">
      <section className="container mx-auto px-4 py-14">
        <div className="max-w-3xl">
          <p className="text-sm text-primary-700"><Link href="/h/answers">← Back to Answers</Link></p>
          <h1 className="mt-3 text-4xl font-bold text-primary-900">Relationships</h1>
          <p className="mt-4 text-lg text-primary-800/80">Improve communication, repair trust, and build strong boundaries with compassion.</p>

          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/h/blogs">
              <Button variant="outline" className="border-primary-300 text-primary-900">Read Articles</Button>
            </Link>
            <Link href="/h/guides-tools">
              <Button className="bg-gradient-to-r from-blue-800 to-amber-600 text-white">Use a Tool</Button>
            </Link>
          </div>

          <div className="mt-10 rounded-2xl border border-primary-200 bg-white/80 p-6">
            <h2 className="text-xl font-semibold text-primary-900">What you’ll find here</h2>
            <ul className="mt-3 list-disc pl-5 text-primary-800/80 space-y-2">
              <li>Short, practical explanations (not jargon-heavy).</li>
              <li>Prompts to reflect and act.</li>
              <li>Resources and next steps if you need more support.</li>
            </ul>
            <p className="mt-4 text-sm text-primary-800/70">
              This section is set up and ready for your content. Add posts under Blog, or connect these pages
              to your CMS/data source when you’re ready.
            </p>
          </div>
        </div>
      </section>
    </div>
  )
}
