  import Link from "next/link"
  import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
  import { Button } from "@/components/ui/button"

  const items = [
    { title: "Life Questions", href: "/h/answers/life-questions", description: "Big questions about meaning, choices, and direction." },
{ title: "Mental Health", href: "/h/answers/mental-health", description: "Grounding support, coping skills, and when to seek help." },
{ title: "Relationships", href: "/h/answers/relationships", description: "Communication, boundaries, and healthier connection." },
{ title: "Career & Purpose", href: "/h/answers/career-purpose", description: "Clarity on work, values, and next steps." },
{ title: "Spiritual Growth", href: "/h/answers/spiritual-growth", description: "Mindfulness, practices, and inner development." }
  ]

  export default function Page() {
    return (
      <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white">
        <section className="container mx-auto px-4 py-14">
          <div className="max-w-3xl">

            <h1 className="text-4xl font-bold text-primary-900">Answers</h1>
            <p className="mt-4 text-lg text-primary-800/80">Browse core life topics and find practical, reflective guidance you can apply today.</p>
          </div>

          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {items.map((it) => (
              <Card key={it.href} className="border-primary-200 shadow-sm hover:shadow-md transition-shadow bg-white/80">
                <CardHeader>
                  <CardTitle className="text-primary-900">{it.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-primary-800/80 mb-4">{it.description}</p>
                  <Link href={it.href}>
                    <Button className="bg-gradient-to-r from-blue-800 to-amber-600 text-white">Explore</Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </div>
    )
  }
