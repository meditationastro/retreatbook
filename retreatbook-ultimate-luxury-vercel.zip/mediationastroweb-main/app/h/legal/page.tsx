import Link from "next/link"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"

const links = [
  { title: "Privacy Policy", href: "/h/privacy", description: "How we collect and use information." },
  { title: "Terms of Use", href: "/h/terms-and-conditions", description: "Rules for using this site and services." },
  { title: "FAQ", href: "/h/faq", description: "Common questions about sessions, booking, and content." },
]

export default function Page() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white">
      <section className="container mx-auto px-4 py-14">
        <div className="max-w-3xl">
          <h1 className="text-4xl font-bold text-primary-900">Legal</h1>
          <p className="mt-4 text-lg text-primary-800/80">
            Policies and information about using AnswerForSelf.
          </p>
        </div>

        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {links.map((l) => (
            <Card key={l.href} className="border-primary-200 bg-white/80">
              <CardHeader>
                <CardTitle className="text-primary-900">{l.title}</CardTitle>
              </CardHeader>
              <CardContent className="text-primary-800/80">
                <p className="mb-3 text-sm">{l.description}</p>
                <Link className="text-primary-700 underline underline-offset-4" href={l.href}>
                  Read →
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  )
}
