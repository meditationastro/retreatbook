import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Page() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white">
      <section className="container mx-auto px-4 py-14">
        <p className="text-sm text-primary-700">
          <Link href="/h/about">← Back to About</Link>
        </p>
        <h1 className="mt-3 text-4xl font-bold text-primary-900">Why AnswerForSelf</h1>
        <p className="mt-4 text-lg text-primary-800/80 max-w-3xl">
          Many sites give advice. AnswerForSelf helps you build your own inner compass—so decisions feel aligned,
          not forced.
        </p>

        <div className="mt-8 max-w-3xl space-y-4 text-primary-800/80">
          <p>
            We organize content by real-life questions (mental health, relationships, career, spirituality) and pair it
            with simple guides and tools that turn insight into action.
          </p>
          <p>
            If you want deeper support, you can book a session or join a retreat to reset and learn a sustainable practice.
          </p>
        </div>

        <div className="mt-10 flex flex-wrap gap-3">
          <Link href="/h/answers">
            <Button className="bg-gradient-to-r from-blue-800 to-amber-600 text-white">Explore Answers</Button>
          </Link>
          <Link href="/h/retreats">
            <Button variant="outline" className="border-primary-300 text-primary-900">See Retreats</Button>
          </Link>
        </div>
      </section>
    </div>
  )
}
