import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function Page() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white">
      <section className="container mx-auto px-4 py-14">
        <p className="text-sm text-primary-700">
          <Link href="/h/about">← Back to About</Link>
        </p>
        <h1 className="mt-3 text-4xl font-bold text-primary-900">Our Philosophy</h1>
        <p className="mt-4 text-lg text-primary-800/80 max-w-3xl">
          AnswerForSelf is built around one core idea: the best answers are the ones you can honestly live by.
          We combine reflection, practical tools, and grounded spirituality to help you hear your own clarity.
        </p>

        <div className="mt-10 grid gap-6 md:grid-cols-2">
          <Card className="border-primary-200 bg-white/80">
            <CardHeader>
              <CardTitle className="text-primary-900">Clarity over certainty</CardTitle>
            </CardHeader>
            <CardContent className="text-primary-800/80">
              We don’t promise a perfect life plan. We help you make the next right step—with confidence and kindness.
            </CardContent>
          </Card>

          <Card className="border-primary-200 bg-white/80">
            <CardHeader>
              <CardTitle className="text-primary-900">Practice, not hype</CardTitle>
            </CardHeader>
            <CardContent className="text-primary-800/80">
              Small daily habits beat motivational bursts. We focus on what you can do today.
            </CardContent>
          </Card>

          <Card className="border-primary-200 bg-white/80">
            <CardHeader>
              <CardTitle className="text-primary-900">Compassion + responsibility</CardTitle>
            </CardHeader>
            <CardContent className="text-primary-800/80">
              You’re not broken. You’re learning. We hold both truth and tenderness at once.
            </CardContent>
          </Card>

          <Card className="border-primary-200 bg-white/80">
            <CardHeader>
              <CardTitle className="text-primary-900">Support when you need it</CardTitle>
            </CardHeader>
            <CardContent className="text-primary-800/80">
              Some challenges require professional care. We encourage reaching out early and appropriately.
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}
