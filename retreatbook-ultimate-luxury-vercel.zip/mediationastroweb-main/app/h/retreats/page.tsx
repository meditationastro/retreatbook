
"use client"
import Countdown from "@/components/Countdown"
import WhatsAppButton from "@/components/WhatsAppButton"

export default function RetreatsPage() {
  const handleCheckout = async () => {
    const res = await fetch("/api/stripe-checkout", { method: "POST" })
    const data = await res.json()
    window.location.href = data.url
  }

  return (
    <main className="max-w-6xl mx-auto px-6 py-20 space-y-16">
      
      <section className="text-center space-y-6">
        <h1 className="text-5xl font-bold">Luxury Himalayan Meditation Retreat</h1>
        <p className="text-xl text-gray-600">
          February 2026 onwards – Secure your transformational journey.
        </p>
        <Countdown />
      </section>

      <section className="text-center">
        <h2 className="text-3xl font-semibold mb-6">Reserve With Deposit</h2>
        <p className="mb-4 text-lg">Deposit: $300 to secure your seat</p>
        <button
          onClick={handleCheckout}
          className="bg-black text-white px-8 py-4 rounded-xl text-lg shadow-lg"
        >
          Pay Deposit
        </button>
      </section>

      <WhatsAppButton />

    </main>
  )
}
