import type { Metadata } from "next";
import { Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "@/components/Theme-provider";
import { SessionProvider } from "next-auth/react";
import { auth } from "@/auth";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "sonner";
import Footer from "@/components/Footer";

const inter = Inter({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Answerforself - Spiritual Guidance & Astrological Insights in Nepal",
  description:
    "Discover inner peace and cosmic wisdom with Answerforself. Expert meditation guidance, astrological readings, and spiritual counseling to help you navigate life's journey.",
  keywords:
    "meditation, astrology, spiritual guidance, horoscope, mindfulness, zodiac, spiritual counseling in Nepal, cosmic wisdom, inner peace",
  authors: [{ name: "Answerforself" }],
  creator: "Answerforself",
  publisher: "Answerforself",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  icons: {
    icon: "/logo.png",
    apple: "/logo.png",
  },
  viewport: {
    width: "device-width",
    initialScale: 1,
    maximumScale: 1,
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#000000" },
  ],
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://answerforself.com",
    siteName: "Answerforself",
    title: "Answerforself - Spiritual Guidance & Astrological Insights",
    description:
      "Discover inner peace and cosmic wisdom with Answerforself. Expert meditation guidance, astrological readings, and spiritual counseling.",
    images: [
      {
        url: "/img/about-main-image.jpg",
        width: 1200,
        height: 630,
        alt: "Answerforself - Spiritual Guidance",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Answerforself - Spiritual Guidance & Astrological Insights",
    description:
      "Discover inner peace and cosmic wisdom with Answerforself. Expert meditation guidance, astrological readings, and spiritual counseling.",
    images: ["/img/about-main-image.jpg"],
    creator: "@answerforself",
  },
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const session = await auth();

  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} ${jetbrainsMono.variable} antialiased`}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <SessionProvider session={session}>
            {children}
            <Toaster />
            <SonnerToaster position="top-center" />
          </SessionProvider>
        </ThemeProvider>
        <Footer />
      </body>
    </html>
  );
}
