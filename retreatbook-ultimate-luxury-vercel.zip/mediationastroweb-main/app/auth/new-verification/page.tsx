import { NewVerificationForm } from '@/components/auth/new-verification';
import React from 'react'

const verificationPage=()=> {
  return (
   <NewVerificationForm/>
  )
}

export default verificationPage;