import ResetForm from "@/components/auth/reset-form";

const ResetPage=()=>{
  return <div>
<ResetForm/>
  </div>
}
export default ResetPage;